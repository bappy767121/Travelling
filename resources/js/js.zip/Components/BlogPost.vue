<template>
    <div class="col-md-8 blog-main col-sm-7">
    <!-- Blog Post 1 -->
    <div class="blog-post">
      <div class="blog-block-img">
        <img :src="imagePaths.blogBig" alt="" class="img-fluid">
      </div>
      <p class="blog-post-cat">Fashion, Lifestyle</p>
      <a href="#">
        <h2 class="blog-post-title">Only Photography What You Love Women Modelling</h2>
      </a>
      <p class="blog-post-meta">
        <img :src="imagePaths.widget3" alt="" class="img-fluid small">
        January 1, 2014 by <a href="#">Mark</a>
      </p>
      <p>
        Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Aenean lacinia bibendum
        nulla sed consectetur. Etiam porta sem malesuada magna mollis euismod. Fusce dapibus, tellus ac cursus commodo,
        tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.
      </p>
      <a href="#" class="read-more">Continue Reading</a>
    </div>

    <!-- Blog Post 2 -->
    <div class="blog-post">
      <div class="row">
        <div class="col-lg-6">
          <div class="blog-post-thumbnail-zone">
            <img :src="imagePaths.pic1" alt="" class="img-fluid">
          </div>
        </div>
        <div class=" col-lg-6">
          <div class="blog-post-content">
            <p class="blog-post-cat mt0">Fashion, Lifestyle</p>
            <a href="#">
              <h3>Only Photography What You Love Women Modelling</h3>
            </a>
            <p class="blog-post-meta">
              <img :src="imagePaths.widget3" alt="" class="img-fluid small">
              January 1, 2014 by <a href="#">Mark</a>
            </p>
            <p>
              Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Aenean lacinia
              bibendum nulla sed consectetur. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh,
              ut fermentum massa justo sit amet risus.
            </p>
            <a href="#" class="read-more">Continue Reading</a>
          </div>
        </div>
      </div>
    </div>

    <!-- Blog Post 3 -->
    <div class="blog-post">
      <div class="row">
        <div class="col-lg-6">
          <div class="blog-post-thumbnail-zone">
            <img :src="imagePaths.pic2" alt="" class="img-fluid">
          </div>
        </div>
        <div class=" col-lg-6">
          <div class="blog-post-content">
            <p class="blog-post-cat mt0">Lifestyle</p>
            <a href="#">
              <h3>Youtube Black and White Photography Ideas</h3>
            </a>
            <p class="blog-post-meta">
              <img :src="imagePaths.widget3" alt="" class="img-fluid small">
              January 1, 2014 by <a href="#">Mark</a>
            </p>
            <p>
              Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Aenean lacinia
              bibendum nulla sed consectetur. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh,
              ut fermentum massa justo sit amet risus.
            </p>
            <a href="#" class="read-more">Continue Reading</a>
          </div>
        </div>
      </div>
    </div>
<!-- /.blog-post LList -->

<div class="blog-post">
    <div class="blog-block-img">
        <img :src="inner3" alt="" class="img-fluid">
    </div>
    <p class="blog-post-cat">Fashion,Lifestyle</p>
    <a href="#">
        <h2 class="blog-post-title">Only Photography What You Love Women Modelling </h2>
    </a>


    <p class="blog-post-meta"> <img :src="imagePaths.inner3" alt="" class="img-fluid small">January 1, 2014 by <a href="#">Mark</a></p>
    <p>Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Aenean lacinia bibendum nulla sed consectetur. Etiam porta sem malesuada magna mollis euismod. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.</p>

    <a href="#" class="read-more">Continue Reading</a>
</div>
<!-- /.blog-post -->

<!-- Blog Paginator -->

<nav aria-label="navigation ">
    <ul class="pagination blog-pagination justify-content-end">
        <li class="page-item disabled">
            <a class="page-link" href="#" tabindex="-1">Older</a>
        </li>
        <li class="page-item"><a class="page-link" href="#">1</a></li>
        <li class="page-item"><a class="page-link" href="#">2</a></li>
        <li class="page-item"><a class="page-link" href="#">3</a></li>
        <li class="page-item">
            <a class="page-link" href="#">Newer</a>
        </li>
    </ul>
</nav>

</div>
<!-- /.blog-main -->
</template>
<script setup>
const imagePaths = {
  blogBig: '/frontend/assets/images/blog/blog-big.jpg',
  widget3: '/frontend/assets/images/blog/widget-3.jpg',
  pic1: '/frontend/assets/images/blog/pic-1.jpg',
  pic2: '/frontend/assets/images/blog/pic-2.jpg',
  pic3: '/frontend/assets/images/blog/pic-3.jpg',
  pic4: '/frontend/assets/images/blog/pic-4.jpg',
  inner3: '/frontend/assets/images/blog/inner-4.jpg'
};
</script>