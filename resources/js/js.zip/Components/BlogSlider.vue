<template>
    <!-- blog-main SIDEBAR RIGHT -->
    <aside class="col-md-4 blog-sidebar col-sm-5">

        <div class="p-3 mb-3 bg-light rounded text-center">
            <div class="top-header ">
                <div class="input-group">
                    <input type="text" class="form-control" id="inlineFormInputGroupUsername" placeholder="Username">
                    <div class="input-group-prepend">
                        <div class="input-group-text"><i class="fa fa-search"></i></div>
                    </div>
                </div>
            </div>
        </div>

        <div class="p-3 mb-3 bg-light rounded text-center">
            <div class="sidebar-about">
                <div class="about-img">
                    <img :src="aboutImagePath" alt="" class="img-fluid rounded-circle">
                </div>
                <h4 class="py-2">Hi! -That's Me</h4>
                <p class="mb-3">Etiam porta <em>sem malesuada magna</em> mollis euismod. Cras mattis consectetur
                    purus sit amet fermentum. Aenean lacinia bibendum nulla sed consectetur.</p>

                <ul class="list-inline social-link">
                    <li class="list-inline-item"><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li class="list-inline-item"><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li class="list-inline-item"><a href="#"><i class="fa fa-rss"></i></a></li>
                    <li class="list-inline-item"><a href="#"><i class="fa fa-instagram"></i></a></li>
                    <li class="list-inline-item"><a href="#"><i class="fa fa-pinterest"></i></a></li>
                </ul>
            </div>
        </div>

        <div class="py-3">
            <div class="sidebar-block">
                <h4 class="sidebar-title">Categories</h4>
                <ol class="list-unstyled mb-0">
                    <li><a href="#">Fashion <span>(10)</span></a></li>
                    <li><a href="#">Lifestyle <span>(5)</span></a></li>
                    <li><a href="#">Hairstyle <span>(7)</span></a></li>
                </ol>
            </div>
        </div>

        <div class="py-3">
            <div class="sidebar-block latest-post">
                <h4 class="sidebar-title">Latest Posts</h4>
                <ol class="list-unstyled">
                    <li>
                        <a href="#">
                            <div class="rpost-img">
                                <img :src="widget4Path" alt="" class="img-fluid">
                            </div>
                            <h5>High Fashion Black and White Photoshoot Art</h5>
                            <p class="text-muted">20 June 2018 </p>
                        </a>
                    </li>

                    <li>
                        <a href="#">
                            <div class="rpost-img">
                                <img :src="widget2Path" alt="" class="img-fluid">
                            </div>
                            <h5>Spanish Women are the Epitome of Beautiful</h5>
                            <p class="text-muted">20 June 2018 </p>
                        </a>
                    </li>

                    <li>
                        <a href="#">
                            <div class="rpost-img">
                                <img :src="widget3Path" alt="" class="img-fluid">
                            </div>
                            <h5>Beauty you lIfe with natural</h5>
                            <p class="text-muted">20 June 2018</p>
                        </a>
                    </li>

                    <li>
                        <a href="#">
                            <div class="rpost-img">
                                <img :src="widget1Path" alt="" class="img-fluid">
                            </div>
                            <h5>Spanish Women are the Epitome of Beautiful</h5>
                            <p class="text-muted">20 June 2018</p>
                        </a>
                    </li>
                </ol>
            </div>
        </div>


        <div class="py-3">
            <div class="sidebar-block instagram">
                <h4 class="sidebar-title">Instagram</h4>

                <div class="instgram-posts">
                    <a href="#"><img :src="widget1Path" alt="" class="img-fluid"></a>
                    <a href="#"><img :src="widget2Path" alt="" class="img-fluid"></a>
                    <a href="#"><img :src="widget3Path" alt="" class="img-fluid"></a>
                    <a href="#"><img :src="widget4Path" alt="" class="img-fluid"></a>
                    <a href="#"><img :src="widget1Path" alt="" class="img-fluid"></a>
                    <a href="#"><img :src="widget2Path" alt="" class="img-fluid"></a>
                    <a href="#"><img :src="widget3Path" alt="" class="img-fluid"></a>
                    <a href="#"><img :src="widget4Path" alt="" class="img-fluid"></a>
                    <a href="#"><img :src="widget1Path" alt="" class="img-fluid"></a>
                </div>
            </div>
        </div>

        <div class="py-3">
            <div class="">
                <h4 class="sidebar-title">Tags</h4>
                <div class="list-unstyled mb-0 tags-cloud">
                    <a href="#">Beauty</a>
                    <a href="#">fashion</a>
                    <a href="#">Hair</a>
                    <a href="#">Makeup</a>
                    <a href="#">Life</a>
                    <a href="#">Sunshine</a>
                    <a href="#">Light</a>
                    <a href="#">fashion</a>
                    <a href="#">Hair</a>
                    <a href="#">Makeup</a>
                    <a href="#">Life</a>
                    <a href="#">Sunshine</a>
                    <a href="#">Light</a>
                </div>
            </div>
        </div>

        <div class="py-3">
            <div class="bg-light text-center subscribe">
                <h4 class="sidebar-title">Subscribe Now</h4>
                <p class="text-muted">Subscribe For latest Newsletter</p>
                <form action="#">
                    <input type="text" class="form-control" placeholder="Type Your Email here">
                    <a href="#" class="btn btn-sm  btn-danger btn-rounded">Subscribe</a>
                </form>
                <p class="font-italic">Don't worry ! We don't spam</p>
            </div>
        </div>

    </aside>
    <!-- /.blog-sidebar -->
</template>
<script setup>
const aboutImagePath = '/frontend/assets/images/blog/author.jpeg'
const widget1Path = '/frontend/assets/images/blog/widget-1.jpg'
const widget2Path = '/frontend/assets/images/blog/widget-2.jpg'
const widget3Path = '/frontend/assets/images/blog/widget-3.jpg'
const widget4Path = '/frontend/assets/images/blog/widget-4.jpg'
</script>