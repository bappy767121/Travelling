<template>
    <div class="popular-wrap">
      <div class="container">
        <div class="row">
          <div class="col-lg-6 mx-auto">
            <div class="post-header border-bottom text-center">
              <h3 class="">Popular post</h3>
              <p>Obcaecati voluptatem hic ducimus maiores accusantium adipisci aspernatur accusantium adipisci aspernatur.</p>
            </div>
          </div>
        </div>
  
        <div class="row">
          <div class="col-lg-3 col-sm-6">
            <a class="popular-post" href="">
              <img :src="imagePaths.blogImg1" alt="" class="img-fluid">
              <div class="post-content">
                <h4 class="ptitle">Messenger Women's Leather Bag Design Idea</h4>
                <p class="text-muted">January 16, 2018</p>
              </div>
            </a>
          </div>
          <div class="col-lg-3 col-sm-6">
            <a class="popular-post" href="">
              <img :src="imagePaths.blogImg2" alt="" class="img-fluid">
              <div class="post-content">
                <h4 class="ptitle">Messenger Women's Leather Bag Design Idea</h4>
                <p class="text-muted">January 16, 2018</p>
              </div>
            </a>
          </div>
          <div class="col-lg-3 col-sm-6">
            <a class="popular-post" href="">
              <img :src="imagePaths.blogImg3" alt="" class="img-fluid">
              <div class="post-content">
                <h4 class="ptitle">Messenger Women's Leather Bag Design Idea</h4>
                <p class="text-muted">January 16, 2018</p>
              </div>
            </a>
          </div>
          <div class="col-lg-3 col-sm-6">
            <a class="popular-post" href="">
              <img :src="imagePaths.blogImg1" alt="" class="img-fluid">
              <div class="post-content">
                <h4 class="ptitle">Messenger Women's Leather Bag Design Idea</h4>
                <p class="text-muted">January 16, 2018</p>
              </div>
            </a>
          </div>
        </div>
      </div>
    </div>
  </template>
  
  <script setup>
  const imagePaths = {
    blogImg1: '/public/frontend/assets/images/blog/blog-img1.jpg',
    blogImg2: '/public/frontend/assets/images/blog/blog-img2.jpg',
    blogImg3: '/public/frontend/assets/images/blog/blog-img3.jpg'
  };
  </script>
  