<template>
<Navbar />

<div class="page-header jumbotron p-3 p-md-5 text-white">
        <div class="dark-overlay"></div>
        <div class="container">
            <div class="col-md-6 px-0 mx-auto ">
                <div class="text-center page-banner-coontent">
                    <h2>Fashion</h2>
                    <p>Eum perspiciatis Ipsa explicabo rerum veritatis repellat atque id quidem cumque et temporibus eaque.</p>
                </div>
            </div>
        </div>
    </div>
    <Contaner/>
    <Popular/>
    <Footer/>
</template>
<script setup>
import Contaner from '../Components/Contaner.vue';
import Footer from '../Components/Footer.vue';
import Navbar from '../Components/Navbar.vue';
import Popular from '../Components/Popular.vue';
</script>