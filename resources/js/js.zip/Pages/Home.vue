<template>
    <div>

        <Head title="Salman Mahmud" />
        <Navbar />
        <Slider />
        <div v-for="blog in blogs" :key="blog.id">
            <Contaner :blogs="blogs" />
        </div>
        <Popular />
        <Footer />
    </div>
</template>
  
<script setup>
import { Head } from '@inertiajs/vue3'
import Navbar from '../Components/Navbar.vue';
import Slider from '../Components/Slider.vue';
import Contaner from '../Components/Contaner.vue';
import Popular from '../Components/Popular.vue';
import Footer from '../Components/Footer.vue';
import { usePage } from '@inertiajs/vue3';

const { props } = usePage();
const blogs = props.blogs;
</script>
  