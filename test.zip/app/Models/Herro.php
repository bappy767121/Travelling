<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Herro extends Model
{
    protected $table = 'hero_image';
}
