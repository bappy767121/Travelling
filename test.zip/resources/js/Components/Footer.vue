<template>
    <footer class="blog-footer">

<div class="footer-social">
    <a href="#" target="_blank" class="fa fa-facebook"></a>
    <a href="#" target="_blank" class="fa fa-behance"></a>
    <a href="#" target="_blank" class="fa fa-twitter"></a>
    <a href="#" target="_blank" class="fa fa-linkedin"></a>
    <a href="#" target="_blank" class="fa fa-google-plus"></a>
    <a href="#" target="_blank" class="fa fa-youtube"></a>
</div>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit integer a urna vitae sem tempus.</p>
<p>2018.Copyright Reserved for <a href="#">Personal</a> by <a href="#">Dreambuzz</a>.</p>
<p>
    <a href="#">Back to top</a>
</p>
</footer>
</template>