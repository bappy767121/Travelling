<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
    <meta name="description" content="blog,resposive,sailor,bootstrap4,modern,html,html5,personal blog,agency blog,video,grid,Clean">
    <meta name="author" content="Dreambuzz">
    <link rel="icon" href="<?php echo e(asset('/frontend/'), false); ?>/assets/images/logo.png">

    

    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(asset('/frontend/'), false); ?>/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!--  Icon Font stylesheet  -->
    <link href="<?php echo e(asset('/frontend/'), false); ?>/assets/css/icofont.css" rel="stylesheet">
    <link href="<?php echo e(asset('/frontend/'), false); ?>/assets/css/font-awesome.css" rel="stylesheet">
    <!--   Common stylesheet  -->
    <link href="<?php echo e(asset('/frontend/'), false); ?>/assets/css/style.css" rel="stylesheet">
    <!--   Custom stylesheet  -->
    <link href="<?php echo e(asset('/frontend/'), false); ?>/assets/css/blog.css" rel="stylesheet">
    <!--   Responsive stylesheet  -->
    <link href="<?php echo e(asset('/frontend/'), false); ?>/assets/css/responsive.css" rel="stylesheet">
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
    <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->head; } ?>
    <!-- <title><?php echo e($title, false); ?></title> -->
  </head>
  <body>
    <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->body; } else { ?><div id="app" data-page="<?php echo e(json_encode($page), false); ?>"></div><?php } ?>
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <script src="<?php echo e(asset('/frontend/'), false); ?>/assets/js/jquery-3.3.1.slim.min.js"></script>
    <script src="<?php echo e(asset('/frontend/'), false); ?>/assets/js/popper.min.js"></script>
    <script src="<?php echo e(asset('/frontend/'), false); ?>/assets/bootstrap/js/bootstrap.min.js"></script>
    <!--  Custom js  -->
    <script src="<?php echo e(asset('/frontend/'), false); ?>/assets/js/custom.js"></script>
  </body>
  
</html><?php /**PATH C:\xampp\htdocs\test\resources\views/app.blade.php ENDPATH**/ ?>